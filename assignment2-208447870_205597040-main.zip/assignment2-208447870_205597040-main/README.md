[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-c66648af7eb3fe8bc4f294546bfd86ef473780cde1dea487d3c4ff354943c9ae.svg)](https://classroom.github.com/online_ide?assignment_repo_id=7892925&assignment_repo_type=AssignmentRepo)
# Assignment2
Website Link:
208447870 Shachar Adam 205597040 Nir Cohen
•	We added a pill that if pacman eats he gets more lives(+1 for each pill)
•	The pill appears and disappears in random empty cells every few seconds
•	We added a Clock that if pacman eats he gets more time
•	The Clock appears and disappears in random empty cells every few seconds

